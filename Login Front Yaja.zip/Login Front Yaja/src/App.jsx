import { useState } from 'react'
import './App.css'
import HeaderForm from './components/HeaderForm/HeaderForm'
import Fomulario from './components/Fomulario/Fomulario'
import RegistroForm from './components/RegistroForm/RegistroForm'
import HomeForm from './components/HomeForm/HomeForm'
import { Outlet } from 'react-router-dom';

import FooterForm from './components/FooterForm/FooterForm.jsx'


function App() {

  return (
    <div className="App">
      <Outlet />
      <FooterForm />
    </div>
  ); 
}

export default App
