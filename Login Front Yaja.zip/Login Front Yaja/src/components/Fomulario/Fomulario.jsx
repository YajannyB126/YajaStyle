// import { useState, useEffect } from 'react';
// import FooterForm from '../FooterForm/FooterForm';
// import './Fomulario.css'
// import { Link, useNavigate } from 'react-router-dom';
// import axios from 'axios';

// const Fomulario = () => {

//     const navigate = useNavigate();

//     const [body, setBody] = useState({ username: '', password: '' })
//     const [messageError, setMessageError] = useState('')
//     const [errors, setErrors] = useState({});
//     let revUser = localStorage.getItem('User')
//     useEffect(() => {
//         (revUser) ? localStorage.removeItem('User') : console.log('sin usuario previo');
//     }, [])

//     const inputChange = ({ target }) => {
//         const { name, value } = target
//         setBody({
//             ...body,
//             [name]: value
//         })
//     }

//     const validateForm = (formData) => {
//         let validationErrors = {};

//         if (formData.username.trim() === '') {
//             validationErrors.username = 'Por favor, ingresa tu nombre de usuario.';
//         }
//         if (formData.password.trim() === '') {
//             validationErrors.password = 'Por favor, ingresa tu contraseña.';
//         }

//         return validationErrors;
//     };

//     const onSubmit = (e) => {
//         e.preventDefault();
//         console.log("🚀 ~ file: Fomulario.jsx:11 ~ Fomulario ~ body:", body)

//         const validationErrors = validateForm(body);

//         setErrors(validationErrors);

//         if (Object.keys(validationErrors).length > 0) {
//             alert('Por favor, completa todos los campos.');
//             return;
//         }

//         axios.post('http://localhost:4000/api/login', body)
//             .then(({ data }) => {
//                 localStorage.setItem('auth', '"yes"')
//                 localStorage.setItem('User', data.user)
//                 navigate('/app');
//             })
//             .catch(({ response }) => {

//                 setMessageError(response.data)

//             })
//     }
//     return (
//         <>
//             <div className="container_login">
//                 <div className="container_login_img_lateral">
//                     <img src="./src/assets/img/imgLogin.jpg" alt="" />
//                 </div>

//                 <div className="container_login_login">
//                     <p className='messaje_error'>{messageError}</p>

//                     <form onSubmit={onSubmit}>
//                         <img className='logolateral' src="/public/logoY.jpg" alt="Logo" />
//                         <div className="container_login_text"><p>Inicia sesión</p></div>
//                         <input className='container_login_input_email' type="text" placeholder='Correo electrónico:' name="username" onChange={inputChange} />
//                         {errors.password && <p className='error-message'>{errors.username}</p>}
//                         <input className='container_login_input_password' type="password" placeholder='Contraseña:' name='password' onChange={inputChange} />
//                         {errors.password && <p className='error-message'>{errors.password}</p>}
//                         <div className="container_login_check_help">
//                             <p>¿No tienes cuenta?</p>
//                             <p> <Link to="register" relative="path">Registrate gratis</Link> </p>
//                         </div>
//                         <div className="buttons_login">
//                             <button className='container_login_button' type="submit">Iniciar Sesión</button>
//                             <button className='container_login_button2'><Link to="register" relative="path">Registrate</Link></button>
//                         </div>

//                     </form>

//                 </div>

//             </div>

//         </>
//     )
// }

// export default Fomulario;

import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './Fomulario.css';

const Fomulario = () => {
    const navigate = useNavigate();

    const [body, setBody] = useState({ username: '', password: '' });
    const [messageError, setMessageError] = useState('');
    const [errors, setErrors] = useState({});
    let revUser = localStorage.getItem('User');

    useEffect(() => {
        revUser ? localStorage.removeItem('User') : console.log('sin usuario previo');
    }, []);

    const inputChange = ({ target }) => {
        const { name, value } = target;
        setBody({
            ...body,
            [name]: value,
        });
    };

    const validateForm = (formData) => {
        let validationErrors = {};

        if (formData.username.trim() === '') {
            validationErrors.username = 'Por favor, ingresa tu nombre de usuario.';
        }
        if (formData.password.trim() === '') {
            validationErrors.password = 'Por favor, ingresa tu contraseña.';
        }

        return validationErrors;
    };

    const displayErrorMessage = (message) => {
        setMessageError(message);
        setTimeout(() => {
            setMessageError('');
        }, 3000);
    };

    const onSubmit = (e) => {
        e.preventDefault();
        console.log('🚀 ~ file: Fomulario.jsx:11 ~ Fomulario ~ body:', body);

        const validationErrors = validateForm(body);
        setErrors(validationErrors);

        if (Object.keys(validationErrors).length > 0) {
            // alert('Por favor, completa todos los campos.');
            const handleCarritoClick = () => {
                Swal.fire({
                    title: "¡Gracias por tu compra!",
                    width: 600,
                    padding: "3em",
                    color: "#716add",
                    background: "#fff url(/images/trees.png)",
                    backdrop: `
                      rgba(0,0,123,0.4)
                      url("/https://www.google.com/url?sa=i&url=https%3A%2F%2Fgifer.com%2Fes%2Fgifs%2Fnyan-cat&psig=AOvVaw1qAB0koyePEEiyDa2v7-KD&ust=1707880485514000&source=images&cd=vfe&opi=89978449&ved=0CBIQjRxqFwoTCPix596sp4QDFQAAAAAdAAAAABAE")
                      left top
                      no-repeat
                    `
                  });
            };
            return;
        }

        axios
            .post('http://localhost:4000/api/login', body)
            .then(({ data }) => {
                localStorage.setItem('auth', '"yes"');
                localStorage.setItem('User', data.user);
                navigate('/app');
            })
            .catch(({ response }) => {
                displayErrorMessage(response.data);
            });
    };


    return (
        <>
            <div className="container_login">

                <div className="container_login_img_lateral">
                    <img src="./src/assets/img/imgLogin.jpg" alt="" />
                </div>

                <div className="container_login_login">
                    <p className="messaje_error">{messageError}</p>

                    <form onSubmit={onSubmit}>
                        <img className="logolateral" src="/public/logoY.jpg" alt="Logo" />
                        <div className="container_login_text">
                            <p>Inicia sesión</p>
                        </div>
                        <input
                            className="container_login_input_email"
                            type="text"
                            placeholder="Correo electrónico:"
                            name="username"
                            onChange={inputChange}
                        />
                        {errors.username && <p className="error-message">{errors.username}</p>}
                        <input
                            className="container_login_input_password"
                            type="password"
                            placeholder="Contraseña:"
                            name="password"
                            onChange={inputChange}
                        />
                        {errors.password && <p className="error-message">{errors.password}</p>}
                        <div className="container_login_check_help">
                            <p>¿No tienes cuenta?</p>
                            <p>
                                {' '}
                                <Link to="register" relative="path">
                                    Registrate gratis
                                </Link>{' '}
                            </p>
                        </div>
                        <div className="buttons_login">
                            <button className="container_login_button" type="submit">
                                Iniciar Sesión
                            </button>
                            <button className="container_login_button2">
                                <Link to="register" relative="path">
                                    Registrate
                                </Link>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </>
    );
};

export default Fomulario;
