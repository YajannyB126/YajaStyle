import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import './RegistroForm.css';

const RegistroForm = () => {
    const navigate = useNavigate();

    const [body, setBody] = useState({
        username: '',
        password: '',
        carrera: '',
        telefono: '',
        identificacion: '',
        nombre: '',
        apellido: '',
    });

    const [messageError, setMessageError] = useState('');
    const [errors, setErrors] = useState({});

    const inputChange = ({ target }) => {
        const { name, value } = target;
        setBody((prevState) => ({
            ...prevState,
            [name]: value,
        }));
    };

    const validateForm = (formData) => {
        let validationErrors = {};
        const nombrePattern = /^[A-Za-z]+$/;

        if (formData.nombre.trim() === '') {
            validationErrors.nombre = 'Por favor, ingresa tu nombre.';
        }else if (!/^[A-Za-z\s]+$/.test(formData.nombre)) {
            validationErrors.nombre = 'Ingrese solo letras para el nombre.';
        }

        if (formData.apellido.trim() === '') {
            validationErrors.apellido = 'Por favor, ingresa tu apellido.';
        }else if (!/^[A-Za-z\s]+$/.test(formData.apellido)) {
            validationErrors.apellido = 'Ingrese solo letras para el apellido.';
        }

        if (formData.identificacion.trim() === '') {
            validationErrors.identificacion = 'Por favor, ingresa tu ID.';
        }else if (!/^\d+$/.test(formData.identificacion)) {
            validationErrors.identificacion = 'Ingrese solo números para la identificación.';
        }

        if (formData.telefono.trim() === '') {
            validationErrors.telefono = 'Por favor, ingresa tu teléfono.';
        }else if (!/^\d+$/.test(formData.identificacion)) {
            validationErrors.identificacion = 'Ingrese solo números para el teléfono.';
        }

        if (formData.username.trim() === '') {
            validationErrors.username = 'Por favor, ingresa tu correo.';
        }else if (!/^\S+@gmail\.com$/.test(formData.correo)) {
            validationErrors.correo = 'Ingrese un correo electrónico de Gmail válido.';
        }

        if (formData.password.trim() === '') {
            validationErrors.password = 'Por favor, ingresa tu contraseña.';
        }
        // else if (!/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{4,}$/.test(formData.password)) {
        //     validationErrors.password = 'La contraseña debe tener al menos 4 caracteres. ej("E,e,#,2")';
        // }

        return validationErrors;
    };

    const onSubmit = (e) => {
        e.preventDefault();

        const validationErrors = validateForm(body);

        setErrors(validationErrors);

        if (Object.keys(validationErrors).length > 0) {
            alert('Por favor, completa todos los campos.');
            return;
        }

        axios
            .post('http://localhost:4000/api/register', body)
            .then(({ data }) => {
                setMessageError('Registro realizado con éxito.');
            })
            .catch((error) => {
                if (error.response && error.response.data) {
                    const errorData = error.response.data;
                    const errorMessage = errorData.sqlMessage;
                    setMessageError(errorMessage);
                } else {
                    setMessageError('Ocurrió un error inesperado.');
                }
            });
    };

    return (
        <>
            <div className="container_loginr">
                {/* <div className="container_login_img">
                    <img src="./src/assets/img/acces11.jpg" alt="" />
                </div> */}
                <div className="container_login_loginr">
                    <form onSubmit={onSubmit}>
                        <p className='messaje_success'>{messageError}</p>
                        <img className='logolateral' src="/public/logoY.jpg" alt="Logo" />

                        <div className="container_login_textr">
                            <h2>Registrarse</h2>
                        </div>
                        <input className='container_login_input_infor' type="text" placeholder='Nombre:' name='nombre' onChange={inputChange} />
                        {errors.nombre && <p className='error-message'>{errors.nombre}</p>}
                        <input className='container_login_input_infor' type="text" placeholder='Apellido:' name='apellido' onChange={inputChange} />
                        {errors.apellido && <p className='error-message'>{errors.apellido}</p>}
                        <input className='container_login_input_infor' type="text" placeholder='Identificacón:' name='identificacion' onChange={inputChange} />
                        {errors.identificacion && <p className='error-message'>{errors.identificacion}</p>}
                        <input className='container_login_input_infor' type="text" placeholder='Telefono:' name='telefono' onChange={inputChange} />
                        {errors.telefono && <p className='error-message'>{errors.telefono}</p>}
                        <input className='container_login_input_emailr' type="text" placeholder='Correo electrónico: ' name='username' onChange={inputChange} />
                        {errors.username && <p className='error-message'>{errors.username}</p>}
                        <input className='container_login_input_passwordr' type="password" placeholder='Contraseña:' name='password' onChange={inputChange} />
                        {errors.password && <p className='error-message'>{errors.password}</p>}

                        <button className='container_login_buttonr' type="submit">
                            Registrarme
                        </button>

                        <div className="container_login_check_helpr">
                            <p>¿Ya tienes cuenta?</p>
                            <p>
                                {' '}
                                <Link to="/" relative="path">
                                    Inicia sesión
                                </Link>{' '}
                            </p>
                        </div>
                    </form>


                </div>

            </div>

        </>
    );
};
export default RegistroForm;