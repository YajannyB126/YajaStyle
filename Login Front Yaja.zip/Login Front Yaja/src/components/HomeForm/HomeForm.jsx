import './HomeForm.css';
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import HeaderForm from '../HeaderForm/HeaderForm';
import FooterForm from '../FooterForm/FooterForm';
import Swal from 'sweetalert2';

const HomeForm = () => {

    const agregarAlCarrito = (producto) => {
        Swal.fire({
            title: "¡Agregado al carrito!",
            text: `${producto.nombre} de ${producto.precio} ha sido añadido al carrito.`,
            imageUrl: producto.imagen,
            precio: producto.precio,
            imageWidth: 170,
            imageHeight: 200,
            imageAlt: "Custom image",
            timer: 5000
        });
    };

    const productos = [
        { id: 1, nombre: 'Arete', precio: 15000, imagen: 'src/assets/img/choco17.jpg' },
        { id: 14, nombre: 'Set completo', precio: 40000, imagen: './src/assets/img/choco1.jpg' },
        { id: 3, nombre: 'Manilla', precio: 20000, imagen: './src/assets/img/manilla.jpg' },
        { id: 4, nombre: 'Collar', precio: 15000, imagen: './src/assets/img/choco11.jpg' },
        { id: 5, nombre: 'Arete', precio: 40000, imagen: './src/assets/img/choco14.jpg' },
        { id: 6, nombre: 'Collar', precio: 30000, imagen: './src/assets/img/choco10.jpg' },
        { id: 7, nombre: 'Reloj', precio: 15000, imagen: './src/assets/img/reloj.jpg' },
        { id: 8, nombre: 'Collar', precio: 20000, imagen: './src/assets/img/choco18.jpg' },
        { id: 9, nombre: 'Collar', precio: 30000, imagen: './src/assets/img/choco9.jpg' },
        { id: 10, nombre: 'Arete', precio: 15000, imagen: './src/assets/img/choco2.jpg' },
        { id: 11, nombre: 'Set completo', precio: 40000, imagen: './src/assets/img/choco5.jpg' },
        { id: 12, nombre: 'Arete', precio: 30000, imagen: './src/assets/img/choco8.jpg' },
        { id: 13, nombre: 'Arete', precio: 15000, imagen: './src/assets/img/choco7.jpg' },
        { id: 14, nombre: 'Manilla', precio: 10000, imagen: './src/assets/img/choco20.jpg' },
        { id: 15, nombre: 'Set completo', precio: 40000, imagen: './src/assets/img/set1.jpg'},
    ];

    return (
        <>
            <HeaderForm />

            <div className="container_home home">
                <div className="header_text">
                    <h1 className='title-home'>"Explora la elegancia de la moda en cada accesorio de nuestra distinguida boutique."</h1>
                    <p>En nuestra colección exclusiva, descubrirás que cada accesorio es una
                        manifestación de arte y buen gusto, creando una sinfonía de elegancia que redefine
                        tu perspectiva de la moda. Sumérgete en este oasis de distinción y permite que tu estilo se
                        eleve a nuevas alturas de esplendor.</p>
                    <a href="https://mujerbamburosa.com/?gad_source=1&gclid=Cj0KCQiAoKeuBhCoARIsAB4WxtfmftquzUaZ8ZK5eoiWf_MQzZRLJnGEUpZfVtlPxs0WeZUbf1IZ80QaApfcEALw_wcB" target="_blank" rel="noopener noreferrer" className='button_1'>Más información</a>
                </div>

                <div className="container_home_img">
                    <img src="./src/assets/img/handHome.jpg" alt="imagen de accesorio." />
                </div>
            </div>



            <main className="main-content">
                <section className="container container-features">
                    <div className="card-feature">
                        <i className="fa-solid fa-plane-up"></i>
                        <div className="feature-content">
                            <span>Envío gratuito a nivel nacional.</span>
                            <p>En pedido superior a $150</p>
                        </div>
                    </div>

                    <div className="card-feature">
                        <i class="fa-solid fa-gift"></i>
                        <div className="feature-content">
                            <span>Tarjeta de regalo.</span>
                            <p>Ofrecemos obsequios a nuestro mejores clientes.</p>
                        </div>
                    </div>
                    <div className="card-feature">
                        <i class="fa-solid fa-headset"></i>
                        <div className="feature-content">
                            <span>Servicio a el cliente.</span>
                            <p>Atención 24/7.</p>
                        </div>
                    </div>
                    <div className="card-feature">
                        <i class="fa-solid fa-money-check"></i>
                        <div className="feature-content">
                            <span>Ahorra tu dinero.</span>
                            <p>Descuentos.</p>
                        </div>
                    </div>

                </section>
            </main>


            {/* productos de accesorios */}
            <div className="container-products">


                {productos.map((producto) => (
                    <div key={producto.id} className="card-product">
                        <div className="container-img">
                            <img className='allImg' src={producto.imagen} alt={producto.nombre} />
                        </div>
                        <div className="content-card-product">
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-regular fa-star"></i>
                            <h3>{producto.nombre}</h3>
                            <span className="add-cart">
                                <i class="fa-solid fa-cart-shopping" onClick={() => agregarAlCarrito(producto)}></i>
                            </span>
                            <p className="price">${producto.precio}</p>
                        </div>
                    </div>
                ))}
            </div>
            <FooterForm />

        </>
    )
}

export default HomeForm;



