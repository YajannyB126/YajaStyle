import './FooterForm.css';

const FooterForm = () => {
    return (
        <>
            <footer>
                <div className="footer-container">
                    <div className="footer-section">
                        <h3>Contacto</h3>
                        <p>Dirección: 24 #77 - 4</p>
                        <p>Email: yajastyle@gmail.com</p>
                        <p>Teléfono: +57 3117667101</p>
                        <p className='cursive'>YAJA STYLE</p>
                    </div>

                    <div className="footer-section">
                        <h3>Información</h3>
                        <p>Reembolsos</p>
                        <p>Términos y condiciones</p>
                        <p>Política de privacidad</p>
                    </div>

                    <div className="footer-section">
                        <h3>Servicios</h3>
                        <p>Envio gratuito</p>
                        <p>Targeta de regalo</p>
                        <p>Servicio al cliente</p>
                    </div>
                </div>
                <div class="contact-info">

                    <div class="social-icons">
                        <span class="facebook">
                            <a href="https://facebook.com/" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-facebook-f"></i></a>
                        </span>

                        <span class="twitter">
                            <a href="https://twitter.com/" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-twitter"></i></a>
                        </span>

                        <span class="youtube">
                            <a href="https://youtube.com/" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-youtube"></i></a>
                        </span>
                        {/* 
                        <span class="pinterest">
                            <a href="https://pinterest.com/" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-pinterest-p"></i></a>
                        </span> */}
                        <span class="instagram">
                            <a href="https://instagram.com/" target="_blank" rel="noopener noreferrer"> <i class="fa-brands fa-instagram"></i></a>
                        </span>

                        <span class="whatsapp">
                            <a href="https://whatsapp.com/" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-whatsapp"></i></a>
                        </span>

                    </div>
                </div>

                <div className="footer-info">
                    <div className="info">
                        <p>© 2024. Todos los derechos reservados.Desarrolladora: Yajanny Mena.</p>
                    </div>
                </div>
            </footer>


        </>
    )
}
export default FooterForm;