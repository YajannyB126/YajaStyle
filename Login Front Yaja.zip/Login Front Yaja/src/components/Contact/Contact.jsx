import React, { useState } from 'react';
import './Contact.css';
import HeaderForm from '../HeaderForm/HeaderForm';
import FooterForm from '../FooterForm/FooterForm';

const Contact = () => {

  return (
    <>
      <div className="container_about">
        <HeaderForm />
        <h3 className='title_about'>Equipo de desarrollo</h3>
        <p className='text_about'>
          Bienvenid@ a YajaStyle, donde la pasión por la moda se encuentra con la dedicación de un equipo apasionado. Conoce a las mentes creativas y los expertos en distribución que dan vida a nuestra visión de estilo, compromiso y calidad en cada accesorio.
          Te invitamos a adentrarte en el corazón de YajaStyle, donde convergen las mentes creativas y los expertos en distribución y calidad de cada accesorio.
        </p>

        <div className="team-container">

          <div className="frame1 frame">
            <div className="team-member ">
              <img src="src/assets/img/women1.jpg" alt="Imagen del equipo" className="team-member-img" />
              <span className="accessory-icon"><i className="fa-solid fa-bag-shopping"></i></span>
              <h3>Yajanny M</h3>
              <p>CEO</p>
              <p>Lider de la empresa.</p>
              <p className="contact-info">Contacto: yaja@yajastyle.com</p>
            </div>

            <div className="team-member">
            <img src="src/assets/img/man1.jpg" alt="Imagen del equipo" className="team-member-img" />
              <span className="accessory-icon"><i className="fa-solid fa-user-tie"></i></span>
              <h3>Zamir Cuesta</h3>
              <p>Gerente Comercial</p>
              <p>Dirige estrategias, impulsa ventas.</p>
              <p className="contact-info">Contacto: zamir.cuesta@yajastyle.com</p>
            </div>

            <div className="team-member">
            <img src="src/assets/img/women2.jpg" alt="Imagen del equipo" className="team-member-img" />
              <span className="accessory-icon"><i className="fa-solid fa-bag-shopping"></i></span>
              <h3>Aky Johnson</h3>
              <p>Gerente de Ventas</p>
              <p>Lidera equipos, maximiza ventas.</p>
              <p className="contact-info">Contacto: aky.johnson@yajastyle.com</p>
            </div>
          </div>

          <div className="frame2">
            <div className="team-member">
            <img src="src/assets/img/man2.jpg" alt="Imagen del equipo" className="team-member-img" />
              <span className="accessory-icon"><i className="fa-solid fa-user-tie"></i></span>
              <h3>Josue Salas</h3>
              <p>Director de Marketing</p>
              <p>Identifica oportunidades de mercado.</p>
              <p className="contact-info">Contacto: josue.salasdoe@yajastyle.com</p>
            </div>

            <div className="team-member">
            <img src="src/assets/img/women3.jpg" alt="Imagen del equipo" className="team-member-img" />
              <span className="accessory-icon"><i className="fa-solid fa-bag-shopping"></i></span>
              <h3>Janny Córdoba</h3>
              <p>Directora financiera</p>
              <p>Promueve estrategias económicas.</p>
              <p className="contact-info">Contacto: janny.cordoba@yajastyle.com</p>
            </div>

            <div className="team-member">
            <img src="src/assets/img/women4.jpg" alt="Imagen del equipo" className="team-member-img" />
              <span className="accessory-icon"><i className="fa-solid fa-bag-shopping"></i></span>
              <h3>Gabi Gomez</h3>
              <p>Director de Diseño</p>
              <p>Creatividad estética e innovación en el diseño.</p>
              <p className="contact-info">Contacto: gabi.gomez@yajastyle.com</p>
            </div>
          </div>
        </div>

      </div>
      <FooterForm />

    </>
  );
};

export default Contact;

