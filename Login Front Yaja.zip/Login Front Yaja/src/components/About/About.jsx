import './About.css'
import HeaderForm from '../HeaderForm/HeaderForm'
import FooterForm from '../FooterForm/FooterForm'


const About = () => {
    return (
        <>
            <HeaderForm />

            <div className="container_about">
                <h1>¿Quiénes Somos?</h1>
                <div className="container_about_text">
                    <div><p className='text'>Somos una empresa distribuidora de accesorios en línea, ubicada en el departamento del Chocó. En nuestro espacio virtual, fusionamos las últimas tendencias con la calidad excepcional. <br /><br /> Desde joyería moderna hasta complementos de moda, cada pieza en YajaStyle cuenta una historia de estilo único. ¡Bienvenido a una experiencia de compra donde el estilo se encuentra con la simplicidad</p></div>
                    <div className="set_star">
                        <div class="star star-1">&#9733;</div>
                        <div class="star star-2">&#9733;</div>
                        <div class="star star-3">&#9733;</div>
                    </div>
                    <div><p className='text'>En YajaStyle, redefinimos la moda a través de accesorios que destacan. Somos más que una tienda en línea; somos una declaración de elegancia. <br /><br /> Creemos en la autenticidad y en la capacidad de los accesorios para expresar tu individualidad. Explora nuestra cuidada selección y descubre cómo puedes elevar tu estilo con las piezas distintivas de YajaStyle.</p></div>

                </div>
            </div>
            {/* <i class="fa-solid fa-check-to-slot"></i> */}

            <section className='container_photos'>
                <h1>Alguno de nuestros productos </h1>
                <article className='gallery'>
                    <div className="img-1">
                        <img src="./src/assets/img/choco13.jpg" alt="" />
                    </div>
                    <div className="img-2">
                        <img src="./src/assets/img/choco17.jpg" alt="" />
                    </div>
                    <div className="img-3">
                        <img src="./src/assets/img/acces16.jpg" alt="" />
                    </div>
                    <div className="img-4">
                        <img src="./src/assets/img/acces17.jpg" alt="" />
                    </div>
                    <div className="img-5">
                        <img src="./src/assets/img/choco3.jpg" alt="" />
                    </div>
                    <div className="img-6">
                        <img src="./src/assets/img/choco10.jpg" alt="" />
                    </div>

                </article>


            </section>
            <FooterForm />



        </>
    )

}

export default About;