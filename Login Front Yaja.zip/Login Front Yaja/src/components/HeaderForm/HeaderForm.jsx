import './HeaderForm.css';
import { Link, useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';


const HeaderForm = () => {
    const navigate = useNavigate();

    let user = localStorage.getItem('User')
    const handleLogout = () => {
        localStorage.removeItem('User', { replace: true });
        navigate('/');
    };

    useEffect(()=>{
        (user)? console.log("el usuario sigue en sesion"): navigate('/');
    },[])

    const [openMenu, setOpenMenu] = useState(false);

    const UpdateMenu = () => {
        setOpenMenu(!openMenu);
    }

    return (
        <>
            <header>
                <div className="navbar">
                    <div className="logo"><img src="/public/logoY.jpg" alt="Logo" /></div>
                    <ul className="links">
                        <li><a href="#"><Link to="/app" relative="path">Home</Link></a></li>
                        <li><a href="#"><Link to="/about" relative="path">About</Link></a></li>
                        <li><a href="#"><Link to="/contact" relative="path">Contatc</Link></a></li>
                        <li><a href="#"><i class="fa-solid fa-user"></i> {user}</a></li>
                    </ul>
                    <a href="#" className="action_btn" onClick={handleLogout}>Sesion Close</a>

                    <div className="toggle_btn" onClick={UpdateMenu}>
                        <i className="fa-solid fa-bars"></i>
                    </div> 
                    
                    {/* <input type="checkbox" id="btn-menu"></input>
                    <label htmlFor="btn-menu" className="toggle_btn">
                        <i className="fa-solid fa-bars"></i>
                    </label> */}   
                </div>

                <div className={`menu_hamburger ${openMenu? 'open' :' '}`}>
                    <ul>
                    <li><a href="#"><Link to="/app" relative="path">Home</Link></a></li>
                        <li><a href="#"><Link to="/about" relative="path">About</Link></a></li>
                        <li><a href="#"><Link to="/contact" relative="path">Contatc</Link></a></li>
                        <li><a href="#"><i class="fa-solid fa-user"></i> {user}</a></li>
                    </ul>
                </div>
                
            </header>
        </>
    )
}

export default HeaderForm;



// import './HeaderForm.css';
// import { Link, useNavigate } from 'react-router-dom';
// import { useState } from 'react';

// const HeaderForm = () => {
//     const navigate = useNavigate();

//     let user = localStorage.getItem('User')
//     const handleLogout = () => {
//         localStorage.removeItem('User');
//         navigate('/', { replace: true }); // Utiliza { replace: true } para reemplazar la entrada actual en el historial
//     };

//     const [openMenu, setOpenMenu] = useState(false);

//     const UpdateMenu = () => {
//         setOpenMenu(!openMenu);
//     }

//     return (
//         <>
//             <header>
//                 <div className="navbar">
//                     <div className="logo"><img src="/src/assets/img/" alt="Logo" /></div>
//                     <ul className="links">
//                         <li><a href="#"><Link to="/app" relative="path">Home</Link></a></li>
//                         <li><a href="#"><Link to="/about" relative="path">About</Link></a></li>
//                         <li><a href="#"><Link to="/contact" relative="path">Contact</Link></a></li>
//                         <li><a href="#"><i className="fa-solid fa-user"></i> {user}</a></li>
//                     </ul>
//                     <a href="#" className="action_btn" onClick={handleLogout}>Session Close</a>

//                     <div className="toggle_btn" onClick={UpdateMenu}>
//                         <i className="fa-solid fa-bars"></i>
//                     </div> 
//                 </div>

//                 <div className={`menu_hamburger ${openMenu ? 'open' : ''}`}>
//                     <ul>
//                         <li><a href="#"><Link to="/app" relative="path">Home</Link></a></li>
//                         <li><a href="#"><Link to="/about" relative="path">About</Link></a></li>
//                         <li><a href="#"><Link to="/contact" relative="path">Contact</Link></a></li>
//                         <li><a href="#"><i className="fa-solid fa-user"></i> {user}</a></li>
//                     </ul>
//                 </div>
//             </header>
//         </>
//     )
// }

// export default HeaderForm;





